                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2504389
My Customized Parametric Divided Box with Sliding Top by victorconka is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

Customized version of http://www.thingiverse.com/thing:2232209

Created with Customizer! http://www.thingiverse.com/apps/customizer/run?thing_id=2232209



# Instructions

Using the following options:

slot_adjust = 1
catch_hole_ratio = .75
lid_buffer_z = -0.25
lid_buffer_y = -0.15
lid_buffer_x = -0.25
hole_buffer_z = .1
hole_buffer_y = .1
hole_buffer_x = .1
catch_bump_ratio = .65
corner_rad = 2
divider_percent_at_max_height = .70
divider_min_height = 13
x_compartment_sizes = [35]
divider_max_height = 23
y_compartment_sizes = [45, 10]
wall_thickness = 2
catch_wall_ratio = .75
catch_hole_diameter = 2
print_catch = no
compartment_height = 25
catch_diameter = 1
divider_thickness = 2